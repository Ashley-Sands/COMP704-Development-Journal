# Game 704 - Machine Learning
## 1806868

Git Repo: https://github.falmouth.ac.uk/AS223343/Comp704-ML-Workshops

Video: 0_Snake.mp4
Description: The video demonstrates a stable_baseline3 PPO model being loaded, trained to the snake game environment.
Model loaded: rt[PPO-snake_gamma_increase-250000]--14750000

Video: 1_Snake_retrain.mp4
Description: The video demonstrates a stable_baseline3 PPO model being loaded and retrained for the snake game environment.
Model loaded: rt[PPO-snake_gamma_increase-250000]--14750000

Video: 3_GA_snake_training_process.mp4
Description: The video demonstrates the generic algorithm process, with a population size of 4, 2 generation and 1 retraining stage. 
             The agents use a stable_baseline3 PPO model, and are trained to play the snake game environment.
             Please Note: That low values for population size, generation, retrain and train timesteps; where chosen to demonstrate 
	     the process only. Therefor it didn’t learn much, as seen in the preview.
             

Video: 4_helicopter.mp4
Description: The video demonstrates a stable_baseline3 PPO model being loaded, trained to the helicopter game environment.
Model loaded: PPO_9_1_heliCave_new_obs_500000
